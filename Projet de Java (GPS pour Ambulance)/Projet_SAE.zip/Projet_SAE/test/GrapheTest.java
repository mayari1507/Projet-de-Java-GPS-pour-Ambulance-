import projet_sae.*;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Tests unitaires de la classe Graphe.
 *
 * Les tests verifient le filtrage des centres, le calcul des matrices de
 * plus courts chemins, les algorithmes de tournee (glouton, 2-opt, deux
 * camions), ainsi que les methodes de recherche de centres. Un graphe
 * "triangle" deterministe est utilise pour les tests qui ont besoin de
 * resultats connus a l'avance ; un graphe genere aleatoirement est utilise
 * pour verifier des proprietes generales valables sur n'importe quel
 * district.
 *
 * @author idris
 */
public class GrapheTest {

    /** Graphe genere aleatoirement, reinitialise avant chaque test. */
    private Graphe grapheAleatoire;

    /**
     * Prepare un graphe aleatoire de 10 centres avant chaque test.
     */
    @Before
    public void setUp() {
        grapheAleatoire = new Graphe();
        grapheAleatoire.genererAleatoire(10);
        grapheAleatoire.construireGraphe();
    }


    /**
     * Verifie que la generation cree bien le nombre demande de centres.
     */
    @Test
    public void genererAleatoireCreeLeBonNombreDeCentres() {
        assertEquals(10, grapheAleatoire.getCentres().size());
    }

    /**
     * Verifie qu'un graphe genere de n centres est connexe : il possede au
     * moins n-1 routes, garanties par l'arbre couvrant construit en premier.
     */
    @Test
    public void genererAleatoireEstConnexe() {
        int nbCentres = grapheAleatoire.getCentres().size();
        assertTrue(grapheAleatoire.getRoutes().size() >= nbCentres - 1);
    }


    /**
     * Verifie qu'un type de centre inconnu leve une exception.
     */
    @Test
    public void typeDeCentreInconnuLeveUneException() {
        try {
            creerCentreViaType("Z");
            fail("Une IllegalArgumentException aurait du etre levee");
        } catch (IllegalArgumentException e) {
        }
    }

    /**
     * Reproduit la logique de creation de centre de Graphe.creerCentre pour
     * verifier qu'un type invalide leve bien une exception, sans dependre
     * d'un fichier CSV externe.
     *
     * @param type le code de type a tester
     * @return jamais de valeur : leve une exception si le type est invalide
     */
    private CentreSante creerCentreViaType(String type) {
        char premiereLettre = type.charAt(0);
        if (premiereLettre == 'M') {
            return new Maternite("S1");
        }
        if (premiereLettre == 'O') {
            return new BlocOperatoire("S1");
        }
        if (premiereLettre == 'N') {
            return new Nutrition("S1");
        }
        throw new IllegalArgumentException("Type de centre inconnu : " + type);
    }
    
    
    /**
     * Verifie que la matrice est symetrique, le graphe etant non oriente.
     */
    @Test
    public void matriceEstSymetrique() {
        Graphe graphe = construireGrapheTriangle();
        double[][] matrice = graphe.calculerMatriceDurees();

        for (int i = 0; i < matrice.length; i++) {
            for (int j = 0; j < matrice.length; j++) {
                assertEquals(matrice[i][j], matrice[j][i], 0.001);
            }
        }
    }

    /**
     * Verifie que la matrice prend en compte les chemins indirects.
     *
     * Dans le triangle S1-S2-S3, la route directe S1-S3 dure 100 alors que le
     * detour S1-S2-S3 ne dure que 30 : le plus court chemin doit valoir 30.
     */
    @Test
    public void matricePrendEnCompteLesCheminsIndirects() {
        Graphe graphe = construireGrapheTriangle();
        double[][] matrice = graphe.calculerMatriceDurees();

        assertEquals(30.0, matrice[0][2], 0.001);
    }


    /**
     * Verifie que la matrice estimee est toujours superieure ou egale a la
     * matrice standard, puisque l'estimation penalise les routes peu fiables.
     */
    @Test
    public void matriceEstimeeEstAuMoinsAussiLongueQueLaStandard() {
        Graphe graphe = construireGrapheTriangle();
        double[][] matriceStandard = graphe.calculerMatriceDurees();
        double[][] matriceEstimee = graphe.calculerMatriceDureesEstimees();

        for (int i = 0; i < matriceStandard.length; i++) {
            for (int j = 0; j < matriceStandard.length; j++) {
                assertTrue(matriceEstimee[i][j] >= matriceStandard[i][j] - 0.001);
            }
        }
    }


    /**
     * Verifie que le filtre "tous" retourne l'ensemble des centres.
     */
    @Test
    public void centresALivrerTousRetourneTousLesCentres() {
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");
        assertEquals(grapheAleatoire.getCentres().size(), aLivrer.size());
    }

    /**
     * Verifie que le filtre par type ne retourne que des centres de ce type.
     */
    @Test
    public void centresALivrerParTypeFiltreCorrectement() {
        List<Integer> maternites = grapheAleatoire.centresALivrer("M");

        for (int i = 0; i < maternites.size(); i++) {
            int index = maternites.get(i);
            assertEquals("M", grapheAleatoire.getCentres().get(index).getType());
        }
    }


    /**
     * Verifie que la tournee gloutonne commence bien au centre 1 (indice 0).
     */
    @Test
    public void gloutonCommenceAuCentreDepart() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");
        List<Integer> tournee = grapheAleatoire.glouton(matrice, aLivrer);

        assertEquals(Integer.valueOf(0), tournee.get(0));
    }

    /**
     * Verifie que la tournee gloutonne visite tous les centres a livrer.
     */
    @Test
    public void gloutonVisiteTousLesCentres() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");
        List<Integer> tournee = grapheAleatoire.glouton(matrice, aLivrer);

        assertEquals(aLivrer.size(), tournee.size());
    }

    /**
     * Verifie la duree d'une tournee connue sur le graphe triangle.
     *
     * La tournee S1 -&gt; S2 -&gt; S3 emprunte les durees 10 puis 20, soit 30
     * au total.
     */
    @Test
    public void calculerDureeTourneeDonneLaBonneValeur() {
        Graphe graphe = construireGrapheTriangle();
        double[][] matrice = graphe.calculerMatriceDurees();

        List<Integer> tournee = new ArrayList<Integer>();
        tournee.add(0);
        tournee.add(1);
        tournee.add(2);

        assertEquals(30.0, graphe.calculerDureeTournee(matrice, tournee), 0.001);
    }


    /**
     * Verifie que l'optimisation 2-opt ne degrade jamais la tournee
     * gloutonne initiale.
     */
    @Test
    public void optimiseNeDegradePasLaTournee() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");

        List<Integer> tourneeGloutonne = grapheAleatoire.glouton(matrice, aLivrer);
        double dureeGloutonne = grapheAleatoire.calculerDureeTournee(matrice, tourneeGloutonne);

        List<Integer> tourneeAOptimiser = new ArrayList<Integer>(tourneeGloutonne);
        List<Integer> tourneeOptimisee = grapheAleatoire.gloutonOptimise(matrice, aLivrer, tourneeAOptimiser);
        double dureeOptimisee = grapheAleatoire.calculerDureeTournee(matrice, tourneeOptimisee);

        assertTrue(dureeOptimisee <= dureeGloutonne);
    }

    /**
     * Verifie que le 2-opt conserve tous les centres de la tournee initiale
     * (il ne fait que reordonner, jamais ajouter ni retirer un centre).
     */
    @Test
    public void optimiseConserveTousLesCentres() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");

        List<Integer> tourneeGloutonne = grapheAleatoire.glouton(matrice, aLivrer);
        List<Integer> tourneeAOptimiser = new ArrayList<Integer>(tourneeGloutonne);
        List<Integer> tourneeOptimisee = grapheAleatoire.gloutonOptimise(matrice, aLivrer, tourneeAOptimiser);

        assertEquals(tourneeGloutonne.size(), tourneeOptimisee.size());
        for (int i = 0; i < tourneeGloutonne.size(); i++) {
            assertTrue(tourneeOptimisee.contains(tourneeGloutonne.get(i)));
        }
    }


    /**
     * Verifie que la solution a deux camions contient bien deux tournees.
     */
    @Test
    public void deuxCamionsRetourneDeuxTournees() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");
        List<Integer> grandeTournee = grapheAleatoire.gloutonOptimise(
                matrice, aLivrer, grapheAleatoire.glouton(matrice, aLivrer));

        List<List<Integer>> solution = grapheAleatoire.deuxCamions(matrice, aLivrer, grandeTournee);

        assertEquals(2, solution.size());
    }

    /**
     * Verifie que deux camions ne font jamais pire qu'un seul camion.
     *
     * La duree du camion le plus lent (deux camions) doit etre inferieure ou
     * egale a la duree d'un seul camion qui ferait toute la tournee.
     */
    @Test
    public void deuxCamionsNeFontPasPireQuUnSeul() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");
        List<Integer> grandeTournee = grapheAleatoire.gloutonOptimise(
                matrice, aLivrer, grapheAleatoire.glouton(matrice, aLivrer));

        double dureeUnCamion = grapheAleatoire.calculerDureeTournee(matrice, grandeTournee);

        List<List<Integer>> solution = grapheAleatoire.deuxCamions(matrice, aLivrer, grandeTournee);
        double dureeLent = maximumDesDeux(matrice, solution);

        assertTrue(dureeLent <= dureeUnCamion + 0.001);
    }

    /**
     * Verifie que chaque camion part bien du centre 1 (indice 0).
     */
    @Test
    public void deuxCamionsPartentTousDuCentreDepart() {
        double[][] matrice = grapheAleatoire.calculerMatriceDurees();
        List<Integer> aLivrer = grapheAleatoire.centresALivrer("tous");
        List<Integer> grandeTournee = grapheAleatoire.gloutonOptimise(
                matrice, aLivrer, grapheAleatoire.glouton(matrice, aLivrer));

        List<List<Integer>> solution = grapheAleatoire.deuxCamions(matrice, aLivrer, grandeTournee);

        assertEquals(Integer.valueOf(0), solution.get(0).get(0));
        assertEquals(Integer.valueOf(0), solution.get(1).get(0));
    }


    /**
     * Verifie que trouverIndexParId retrouve le bon indice pour un id
     * existant.
     */
    @Test
    public void trouverIndexParIdTrouveLeBonIndice() {
        String idPremierCentre = grapheAleatoire.getCentres().get(0).getId();
        assertEquals(0, grapheAleatoire.trouverIndexParId(idPremierCentre));
    }

    /**
     * Verifie que trouverIndexParId retourne -1 pour un id inexistant.
     */
    @Test
    public void trouverIndexParIdRetourneMoinsUnSiAbsent() {
        assertEquals(-1, grapheAleatoire.trouverIndexParId("IdQuiNExistePas"));
    }

    /**
     * Verifie que trouverCentreParId retrouve le bon centre pour un id
     * existant.
     */
    @Test
    public void trouverCentreParIdTrouveLeBonCentre() {
        CentreSante premierCentre = grapheAleatoire.getCentres().get(0);
        CentreSante trouve = grapheAleatoire.trouverCentreParId(premierCentre.getId());

        assertEquals(premierCentre, trouve);
    }

    /**
     * Verifie que trouverCentreParId retourne null pour un id inexistant.
     */
    @Test
    public void trouverCentreParIdRetourneNullSiAbsent() {
        assertNull(grapheAleatoire.trouverCentreParId("IdQuiNExistePas"));
    }


    /**
     * Construit un petit graphe triangle aux durees connues, pour les tests
     * deterministes.
     *
     * Routes : S1-S2 = 10 min, S2-S3 = 20 min, S1-S3 = 100 min. Le plus
     * court chemin de S1 a S3 passe donc par S2 (30 min).
     *
     * @return le graphe triangle construit et pret a l'emploi
     */
    private Graphe construireGrapheTriangle() {
        Graphe graphe = new Graphe();
        List<CentreSante> centres = graphe.getCentres();
        centres.add(new Maternite("S1"));
        centres.add(new BlocOperatoire("S2"));
        centres.add(new Nutrition("S3"));

        List<Route> routes = graphe.getRoutes();
        routes.add(new Route(centres.get(0), centres.get(1), 0.8, 10, 10));
        routes.add(new Route(centres.get(1), centres.get(2), 0.8, 10, 20));
        routes.add(new Route(centres.get(0), centres.get(2), 0.8, 10, 100));

        graphe.construireGraphe();
        return graphe;
    }

    /**
     * Calcule la duree du camion le plus lent d'une solution a deux camions.
     *
     * @param matrice  la matrice des durees
     * @param solution la liste des deux tournees
     * @return la plus grande des deux durees
     */
    private double maximumDesDeux(double[][] matrice, List<List<Integer>> solution) {
        double duree1 = grapheAleatoire.calculerDureeTournee(matrice, solution.get(0));
        double duree2 = grapheAleatoire.calculerDureeTournee(matrice, solution.get(1));
        if (duree1 > duree2) {
            return duree1;
        }
        return duree2;
    }
}