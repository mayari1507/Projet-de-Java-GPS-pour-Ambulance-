/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IHM;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.swingViewer.ViewPanel;
import org.graphstream.ui.view.Viewer;

import projet_sae.CentreSante;
import projet_sae.Graphe;
import projet_sae.Route;

/**
 * Fenêtre principale de traitement du district : affichage du graphe,
 * outils de mise en évidence (routes risquées, itinéraires), envoi de
 * camion(s), et consultation des informations détaillées d'un centre.
 *
 * La partie droite bascule entre deux vues (le graphe et les informations
 * d'un centre sélectionné) grâce à un CardLayout.
 *
 * @author idris
 */
public class FenetreTraitement extends JFrame {

    /** Incrément de taille de police appliqué aux titres de rubrique. */
    private static final int INCREMENT_TAILLE_TITRE = 5;

    /** Largeur commune des champs de saisie et des listes déroulantes. */
    private static final int LARGEUR_CHAMPS = 200;

    /** Identifiant de la carte affichant le graphe. */
    public static final String CARTE_GRAPHE = "GRAPHE";

    /** Identifiant de la carte affichant les informations d'un centre. */
    public static final String CARTE_CENTRE = "CENTRE";

    /** Panneau de gauche regroupant tous les outils de traitement. */
    private JPanel panneauGauche;

    /** Bouton qui réinitialise l'affichage du graphe. */
    private JButton boutonReinitialiser;

    /** Gestionnaire de cartes pour basculer entre graphe et infos centre. */
    private CardLayout cardLayout;

    /** Panneau de droite, conteneur des deux cartes. */
    private JPanel panneauDroit;

    /** Carte affichant le graphe GraphStream. */
    private JPanel panneauGraphe;

    /** Carte affichant les informations d'un centre sélectionné. */
    private JPanel panneauCentre;

    /** District actuellement affiché et manipulé. */
    private Graphe district;

    /** Viewer GraphStream chargé d'afficher le graphe du district. */
    private Viewer viewerGraphe;

    /** Vue Swing intégrée dans panneauGraphe. */
    private ViewPanel vueGraphe;

    /** Panneau récapitulant le nombre de centres par type. */
    private JPanel panneauInfos;

    /** Label affichant le nombre de maternités. */
    private JLabel labelMaternites;

    /** Label affichant le nombre de blocs opératoires. */
    private JLabel labelBlocsOperatoires;

    /** Label affichant le nombre de centres de nutrition. */
    private JLabel labelNutrition;

    /** Rubrique de mise en évidence des routes risquées. */
    private JPanel panneauRubriqueSeuil;

    /** Titre de la rubrique seuil. */
    private JLabel titreSeuil;

    /** Label du champ de saisie du seuil. */
    private JLabel labelSeuil;

    /** Champ de saisie du seuil de fiabilité. */
    private JTextField champSeuil;

    /** Bouton qui déclenche la mise en évidence des routes risquées. */
    private JButton boutonTracerSeuil;

    /** Rubrique de calcul d'itinéraire entre deux centres. */
    private JPanel panneauRubriqueItineraires;

    /** Titre de la rubrique itinéraires. */
    private JLabel titreItineraires;

    /** Label du centre de départ. */
    private JLabel labelCentreDepart;

    /** Liste déroulante du centre de départ. */
    private JComboBox<String> listeCentreDepart;

    /** Modèle de la liste déroulante du centre de départ. */
    private DefaultComboBoxModel<String> modeleCentreDepart;

    /** Label du centre d'arrivée. */
    private JLabel labelCentreArrivee;

    /** Liste déroulante du centre d'arrivée. */
    private JComboBox<String> listeCentreArrivee;

    /** Modèle de la liste déroulante du centre d'arrivée. */
    private DefaultComboBoxModel<String> modeleCentreArrivee;

    /** Bouton qui déclenche le calcul et l'affichage de l'itinéraire. */
    private JButton boutonTracerItineraire;

    /** Rubrique d'envoi de camion(s). */
    private JPanel panneauRubriqueEnvoi;

    /** Titre de la rubrique envoi. */
    private JLabel titreEnvoi;

    /** Ligne contenant les boutons radio du nombre de camions. */
    private JPanel ligneNombreCamions;

    /** Bouton radio pour 1 camion. */
    private JRadioButton radioUnCamion;

    /** Bouton radio pour 2 camions. */
    private JRadioButton radioDeuxCamions;

    /** Groupe exclusif des boutons radio du nombre de camions. */
    private ButtonGroup groupeNombreCamions;

    /** Ligne contenant les boutons radio du type de centre. */
    private JPanel ligneTypeCentre;

    /** Bouton radio pour le type maternité. */
    private JRadioButton radioMaternite;

    /** Bouton radio pour le type bloc opératoire. */
    private JRadioButton radioBlocOperatoire;

    /** Bouton radio pour le type nutrition. */
    private JRadioButton radioNutrition;

    /** Bouton radio pour tous les types de centre. */
    private JRadioButton radioTousLesCentres;

    /** Groupe exclusif des boutons radio du type de centre. */
    private ButtonGroup groupeTypeCentre;

    /** Bouton qui déclenche le calcul et l'affichage de la tournée. */
    private JButton boutonTracerEnvoi;

    /** Contenu défilant de la carte centre. */
    private JPanel contenuCentre;

    /** Barre de défilement de la carte centre. */
    private JScrollPane defilementCentre;

    /** Titre de la carte centre. */
    private JLabel titreCentre;

    /** Rubrique des informations générales du centre sélectionné. */
    private JPanel panneauInfosCentre;

    /** Titre de la rubrique informations générales. */
    private JLabel titreInfosCentre;

    /** Label affichant l'identifiant du centre sélectionné. */
    private JLabel labelIdCentre;

    /** Label affichant le type du centre sélectionné. */
    private JLabel labelTypeCentre;

    /** Rubrique des centres les plus proches par type. */
    private JPanel panneauPlusProches;

    /** Titre de la rubrique centres les plus proches. */
    private JLabel titrePlusProches;

    /** Table des centres les plus proches par type. */
    private JTable tablePlusProches;

    /** Modèle de la table des centres les plus proches. */
    private DefaultTableModel modelePlusProches;

    /** Barre de défilement de la table des centres les plus proches. */
    private JScrollPane defilementPlusProches;

    /** Rubrique des distances avec tous les centres. */
    private JPanel panneauDistances;

    /** Titre de la rubrique distances. */
    private JLabel titreDistances;

    /** Table des distances avec tous les centres. */
    private JTable tableDistances;

    /** Modèle de la table des distances. */
    private DefaultTableModel modeleDistances;

    /** Barre de défilement de la table des distances. */
    private JScrollPane defilementDistances;

    /** Rubrique des durées minimales avec tous les centres. */
    private JPanel panneauDurees;

    /** Titre de la rubrique durées. */
    private JLabel titreDurees;

    /** Table des durées minimales. */
    private JTable tableDurees;

    /** Modèle de la table des durées. */
    private DefaultTableModel modeleDurees;

    /** Barre de défilement de la table des durées. */
    private JScrollPane defilementDurees;

    /**
     * Construit la fenêtre de traitement pour le district donné.
     *
     * @param district le district à afficher et traiter
     */
    public FenetreTraitement(Graphe district) {
        super("Projet SAÉ - Traitement");
        this.district = district;
        this.initComposants();
    }

    /**
     * Initialise et assemble tous les composants graphiques de la fenêtre.
     */
    private void initComposants() {

        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(1100, 750);
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());

        this.construirePanneauGauche();
        this.construirePanneauDroite();
        this.ajouterEcouteurs();

        this.add(this.panneauGauche, BorderLayout.WEST);
        this.add(this.panneauDroit, BorderLayout.CENTER);

        this.setVisible(true);
    }

    /**
     * Attache les écouteurs de tous les boutons de la fenêtre : seuil de
     * fiabilité, itinéraire, envoi de camion(s), et réinitialisation.
     */
    private void ajouterEcouteurs() {
        this.boutonTracerSeuil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String saisieSeuil = champSeuil.getText().trim();
                int seuil = 0;
                try {
                    seuil = Integer.parseInt(saisieSeuil);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(
                            FenetreTraitement.this,
                            "Veuillez saisir un seuil entier valide.",
                            "Saisie invalide",
                            JOptionPane.WARNING_MESSAGE);
                }

                Graph g = district.getGraph();
                for (Route r : district.getRoutes()) {
                    Edge arete = g.getEdge(r.getSource().getId() + "_" + r.getDestination().getId());
                    if (arete == null) {
                        arete = g.getEdge(r.getDestination().getId() + "_" + r.getSource().getId());
                    }
                    if (arete != null) {
                        arete.setAttribute("ui.style", "fill-color: black; size: 1px;");
                        arete.setAttribute("ui.label", r.getFiabilite() + "/" + r.getDistance() + " km/" + r.getDuree() + "min");
                        arete.setAttribute("fiabilite", r.getFiabilite());
                        arete.setAttribute("distance", r.getDistance());
                        arete.setAttribute("duree", r.getDuree());
                    }
                }

                if (seuil != 0) {
                    district.afficherRoutesRisquees(seuil);
                }
            }
        });

        this.boutonTracerItineraire.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                district.suppInfos();
                String centreDepart = (String) listeCentreDepart.getSelectedItem();
                String centreArrivee = (String) listeCentreArrivee.getSelectedItem();
                district.cheminSecurise(centreDepart, centreArrivee);
                district.plusCourtChemin(centreDepart, centreArrivee);
            }
        });

        this.boutonTracerEnvoi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (groupeNombreCamions.getSelection() == null || groupeTypeCentre.getSelection() == null) {
                    JOptionPane.showMessageDialog(
                            FenetreTraitement.this,
                            "Veuillez choisir un nombre de camions et un type de centre.",
                            "Sélection manquante",
                            JOptionPane.WARNING_MESSAGE);
                }
                else {
                    double[][] matriceGFichier = district.calculerMatriceDurees();
                    String type = null;

                    if (radioMaternite.isSelected()) {
                        type = "M";
                    } else if (radioBlocOperatoire.isSelected()) {
                        type = "O";
                    } else if (radioNutrition.isSelected()) {
                        type = "N";
                    } else if (radioTousLesCentres.isSelected()) {
                        type = "tous";
                    }

                    if (radioUnCamion.isSelected()) {
                        List<Integer> tourneeGlouton = district.Algo1CamionGlouton(type, matriceGFichier);
                        district.Algo1CamionOptimise(type, matriceGFichier, tourneeGlouton);
                    } else if (radioDeuxCamions.isSelected()) {
                        List<Integer> tourneeGlouton = district.Algo1CamionGlouton(type, matriceGFichier);
                        List<Integer> tourneeGloutonOptimise = district.Algo1CamionOptimise(type, matriceGFichier, tourneeGlouton);
                        district.Algo2Camion(type, matriceGFichier, tourneeGloutonOptimise);
                    }
                }
            }
        });

        this.boutonReinitialiser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                district.setGraphe(new SingleGraph("District"));
                district.construireGraphe();
                district.afficher();

                afficherDistrict(district);
                panneauGraphe.revalidate();
                panneauGraphe.repaint();
                cardLayout.show(panneauDroit, CARTE_GRAPHE);
            }
        });
    }

    /**
     * Construit le panneau de gauche : récapitulatif des centres, puis les
     * trois rubriques d'outils, puis le bouton de réinitialisation.
     */
    private void construirePanneauGauche() {
        this.panneauGauche = new JPanel();
        this.panneauGauche.setLayout(new BoxLayout(this.panneauGauche, BoxLayout.Y_AXIS));
        this.panneauGauche.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        this.construirePanneauInfos();
        this.construireRubriqueSeuil();
        this.construireRubriqueItineraires();
        this.construireRubriqueEnvoi();

        this.panneauGauche.add(this.panneauInfos);
        this.panneauGauche.add(Box.createVerticalStrut(15));
        this.panneauGauche.add(this.panneauRubriqueSeuil);
        this.panneauGauche.add(Box.createVerticalStrut(15));
        this.panneauGauche.add(this.panneauRubriqueItineraires);
        this.panneauGauche.add(Box.createVerticalStrut(15));
        this.panneauGauche.add(this.panneauRubriqueEnvoi);

        this.boutonReinitialiser = new JButton("Réinitialiser");
        this.boutonReinitialiser.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.panneauGauche.add(Box.createVerticalStrut(15));
        this.panneauGauche.add(this.boutonReinitialiser);

        this.panneauGauche.add(Box.createVerticalGlue());
    }

    /**
     * Construit le panneau récapitulant le nombre de centres de chaque type,
     * avec une pastille de couleur correspondant à la feuille de style du
     * graphe.
     */
    private void construirePanneauInfos() {
        this.panneauInfos = new JPanel();
        this.panneauInfos.setLayout(new BoxLayout(this.panneauInfos, BoxLayout.Y_AXIS));
        this.panneauInfos.setBorder(this.creerBordureRubrique());

        JPanel orange = new JPanel();
        orange.setBackground(new Color(250, 112, 37));
        orange.setPreferredSize(new Dimension(12, 12));
        JPanel vert = new JPanel();
        vert.setBackground(new Color(20, 168, 94));
        vert.setPreferredSize(new Dimension(12, 12));
        JPanel jaune = new JPanel();
        jaune.setBackground(new Color(250, 221, 5));
        jaune.setPreferredSize(new Dimension(12, 12));

        int nbMaternites = 0;
        int nbBlocs = 0;
        int nbNutrition = 0;
        for (CentreSante centre : this.district.getCentres()) {
            if (centre.getType().equals("M")) {
                nbMaternites++;
            } else if (centre.getType().equals("O")) {
                nbBlocs++;
            } else if (centre.getType().equals("N")) {
                nbNutrition++;
            }
        }

        this.labelMaternites = new JLabel("Maternités : " + nbMaternites);
        this.labelBlocsOperatoires = new JLabel("Bloc Opératoires : " + nbBlocs);
        this.labelNutrition = new JLabel("Nutrition : " + nbNutrition);

        JPanel ligne1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        ligne1.add(orange);
        ligne1.add(this.labelMaternites);
        JPanel ligne2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        ligne2.add(vert);
        ligne2.add(this.labelBlocsOperatoires);
        JPanel ligne3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        ligne3.add(jaune);
        ligne3.add(this.labelNutrition);

        this.panneauInfos.add(ligne1);
        this.panneauInfos.add(Box.createVerticalStrut(5));
        this.panneauInfos.add(ligne2);
        this.panneauInfos.add(Box.createVerticalStrut(5));
        this.panneauInfos.add(ligne3);

        this.panneauInfos.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.panneauInfos.getPreferredSize().height));
    }

    /**
     * Construit la rubrique permettant de mettre en évidence les routes dont
     * la fiabilité dépasse un seuil saisi par l'utilisateur.
     */
    private void construireRubriqueSeuil() {
        this.panneauRubriqueSeuil = new JPanel();
        this.panneauRubriqueSeuil.setLayout(new BoxLayout(this.panneauRubriqueSeuil, BoxLayout.Y_AXIS));
        this.panneauRubriqueSeuil.setBorder(this.creerBordureRubrique());

        this.titreSeuil = new JLabel("Routes les plus risquées à partir du seuil");
        styliserTitre(this.titreSeuil);

        this.labelSeuil = new JLabel("Entrer le seuil (entre 0 et 100) :");
        this.labelSeuil.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.champSeuil = new JTextField(10);
        this.champSeuil.setPreferredSize(new Dimension(LARGEUR_CHAMPS, this.champSeuil.getPreferredSize().height));
        this.champSeuil.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.boutonTracerSeuil = new JButton("Tracer");
        this.boutonTracerSeuil.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.panneauRubriqueSeuil.add(this.titreSeuil);
        this.panneauRubriqueSeuil.add(Box.createVerticalStrut(10));
        this.panneauRubriqueSeuil.add(this.labelSeuil);
        this.panneauRubriqueSeuil.add(Box.createVerticalStrut(5));
        this.panneauRubriqueSeuil.add(this.champSeuil);
        this.panneauRubriqueSeuil.add(Box.createVerticalStrut(10));
        this.panneauRubriqueSeuil.add(this.boutonTracerSeuil);

        this.panneauRubriqueSeuil.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.panneauRubriqueSeuil.getPreferredSize().height));
    }

    /**
     * Construit la rubrique de calcul d'itinéraire entre un centre de départ
     * et un centre d'arrivée choisis dans deux listes déroulantes.
     */
    private void construireRubriqueItineraires() {
        this.panneauRubriqueItineraires = new JPanel();
        this.panneauRubriqueItineraires.setLayout(new BoxLayout(this.panneauRubriqueItineraires, BoxLayout.Y_AXIS));
        this.panneauRubriqueItineraires.setBorder(this.creerBordureRubrique());

        this.titreItineraires = new JLabel("Meilleurs itinéraires");
        styliserTitre(this.titreItineraires);

        this.modeleCentreDepart = new DefaultComboBoxModel<>();
        this.modeleCentreArrivee = new DefaultComboBoxModel<>();
        this.remplirModelesCentres();

        this.labelCentreDepart = new JLabel("Centre de départ :");
        this.labelCentreDepart.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.listeCentreDepart = new JComboBox<>(this.modeleCentreDepart);
        this.listeCentreDepart.setPreferredSize(new Dimension(LARGEUR_CHAMPS, this.listeCentreDepart.getPreferredSize().height));
        this.listeCentreDepart.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.labelCentreArrivee = new JLabel("Centre d'arrivée :");
        this.labelCentreArrivee.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.listeCentreArrivee = new JComboBox<>(this.modeleCentreArrivee);
        this.listeCentreArrivee.setPreferredSize(new Dimension(LARGEUR_CHAMPS, this.listeCentreArrivee.getPreferredSize().height));
        this.listeCentreArrivee.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.boutonTracerItineraire = new JButton("Tracer");
        this.boutonTracerItineraire.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.panneauRubriqueItineraires.add(this.titreItineraires);
        this.panneauRubriqueItineraires.add(Box.createVerticalStrut(10));
        this.panneauRubriqueItineraires.add(this.labelCentreDepart);
        this.panneauRubriqueItineraires.add(Box.createVerticalStrut(5));
        this.panneauRubriqueItineraires.add(this.listeCentreDepart);
        this.panneauRubriqueItineraires.add(Box.createVerticalStrut(10));
        this.panneauRubriqueItineraires.add(this.labelCentreArrivee);
        this.panneauRubriqueItineraires.add(Box.createVerticalStrut(5));
        this.panneauRubriqueItineraires.add(this.listeCentreArrivee);
        this.panneauRubriqueItineraires.add(Box.createVerticalStrut(10));
        this.panneauRubriqueItineraires.add(this.boutonTracerItineraire);

        this.panneauRubriqueItineraires.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.panneauRubriqueItineraires.getPreferredSize().height));
    }

    /**
     * Remplit les deux listes déroulantes (départ et arrivée) avec
     * l'identifiant de chaque centre du graphe.
     */
    private void remplirModelesCentres() {
        String idCentre;
        Graph graphe = this.district.getGraph();
        for (int i = 0; i < graphe.getNodeCount(); i++) {
            idCentre = graphe.getNode(i).getId();
            this.modeleCentreDepart.addElement(idCentre);
            this.modeleCentreArrivee.addElement(idCentre);
        }
    }

    /**
     * Construit la rubrique d'envoi de camion(s) : choix du nombre de
     * camions (1 ou 2) et du type de centre à livrer.
     */
    private void construireRubriqueEnvoi() {
        this.panneauRubriqueEnvoi = new JPanel();
        this.panneauRubriqueEnvoi.setLayout(new BoxLayout(this.panneauRubriqueEnvoi, BoxLayout.Y_AXIS));
        this.panneauRubriqueEnvoi.setBorder(this.creerBordureRubrique());

        this.titreEnvoi = new JLabel("Envoi de camion(s)");
        styliserTitre(this.titreEnvoi);

        this.radioUnCamion = new JRadioButton("1 camion");
        this.radioDeuxCamions = new JRadioButton("2 camions");

        this.groupeNombreCamions = new ButtonGroup();
        this.groupeNombreCamions.add(this.radioUnCamion);
        this.groupeNombreCamions.add(this.radioDeuxCamions);

        this.ligneNombreCamions = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        this.ligneNombreCamions.add(this.radioUnCamion);
        this.ligneNombreCamions.add(this.radioDeuxCamions);
        this.ligneNombreCamions.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.ligneNombreCamions.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.ligneNombreCamions.getPreferredSize().height));

        this.radioMaternite = new JRadioButton("Maternité");
        this.radioBlocOperatoire = new JRadioButton("Bloc Opératoire");
        this.radioNutrition = new JRadioButton("Nutrition");
        this.radioTousLesCentres = new JRadioButton("Tous les centres");

        this.groupeTypeCentre = new ButtonGroup();
        this.groupeTypeCentre.add(this.radioMaternite);
        this.groupeTypeCentre.add(this.radioBlocOperatoire);
        this.groupeTypeCentre.add(this.radioNutrition);
        this.groupeTypeCentre.add(this.radioTousLesCentres);

        this.ligneTypeCentre = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        this.ligneTypeCentre.add(this.radioMaternite);
        this.ligneTypeCentre.add(this.radioBlocOperatoire);
        this.ligneTypeCentre.add(this.radioNutrition);
        this.ligneTypeCentre.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.ligneTypeCentre.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.ligneTypeCentre.getPreferredSize().height));

        this.radioTousLesCentres.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.boutonTracerEnvoi = new JButton("Tracer");
        this.boutonTracerEnvoi.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.panneauRubriqueEnvoi.add(this.titreEnvoi);
        this.panneauRubriqueEnvoi.add(Box.createVerticalStrut(10));
        this.panneauRubriqueEnvoi.add(this.ligneNombreCamions);
        this.panneauRubriqueEnvoi.add(Box.createVerticalStrut(10));
        this.panneauRubriqueEnvoi.add(this.ligneTypeCentre);
        this.panneauRubriqueEnvoi.add(this.radioTousLesCentres);
        this.panneauRubriqueEnvoi.add(Box.createVerticalStrut(10));
        this.panneauRubriqueEnvoi.add(this.boutonTracerEnvoi);

        this.panneauRubriqueEnvoi.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.panneauRubriqueEnvoi.getPreferredSize().height));
    }

    /**
     * Construit le panneau de droite : un CardLayout regroupant la carte du
     * graphe et la carte des informations d'un centre.
     */
    private void construirePanneauDroite() {
        this.cardLayout = new CardLayout();
        this.panneauDroit = new JPanel(this.cardLayout);

        this.construirePanneauGraphe();
        this.construirePanneauCentre();

        this.panneauDroit.add(this.panneauGraphe, CARTE_GRAPHE);
        this.panneauDroit.add(this.panneauCentre, CARTE_CENTRE);

        this.cardLayout.show(this.panneauDroit, CARTE_GRAPHE);
    }

    /**
     * Construit la carte affichant le graphe GraphStream du district.
     */
    private void construirePanneauGraphe() {
        this.panneauGraphe = new JPanel(new BorderLayout());
        this.panneauGraphe.setBorder(BorderFactory.createTitledBorder("Affichage du District"));
        this.panneauGraphe.setPreferredSize(new Dimension(700, 600));

        this.afficherDistrict(this.district);
    }

    /**
     * Construit et intègre la vue GraphStream du district dans le panneau
     * graphe, et attache l'écouteur de clic droit sur les sommets.
     *
     * Un clic droit sur un centre ouvre la carte d'informations
     * correspondante. Un ancien viewer éventuellement ouvert est fermé
     * proprement avant la création du nouveau.
     *
     * @param district le district à afficher
     */
    public void afficherDistrict(Graphe district) {
        this.district = district;
        this.panneauGraphe.removeAll();

        

        this.viewerGraphe = new Viewer(district.getGraph(), Viewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
        this.viewerGraphe.enableAutoLayout();
        this.vueGraphe = this.viewerGraphe.addDefaultView(false);

        this.vueGraphe.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    afficherInfosCentre("S1");
                    cardLayout.show(panneauDroit, CARTE_CENTRE);
                }
            }
        });
        this.panneauGraphe.add(this.vueGraphe, BorderLayout.CENTER);
    }

    /**
     * Met à jour les labels d'identité du centre puis remplit les trois
     * tableaux d'informations (centres les plus proches, distances, durées).
     *
     * @param idCentre l'identifiant du centre sélectionné
     */
    private void afficherInfosCentre(String idCentre) {
        CentreSante centre = this.district.trouverCentreParId(idCentre);
        
        if (centre != null) {
            this.labelIdCentre.setText("ID du centre : " + centre.getId());
            this.labelTypeCentre.setText("Type du centre : " + centre.getType());
            this.remplirPlusProches(idCentre);
            this.remplirDistances(idCentre);
            this.remplirDurees(idCentre);
        }
    }

    /**
     * Construit la carte des informations d'un centre : identité, puis les
     * trois rubriques de tableaux.
     */
    private void construirePanneauCentre() {
        this.panneauCentre = new JPanel(new BorderLayout());

        this.contenuCentre = new JPanel();
        this.contenuCentre.setLayout(new BoxLayout(this.contenuCentre, BoxLayout.Y_AXIS));
        this.contenuCentre.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        this.titreCentre = new JLabel("Infos Centre");
        styliserTitre(this.titreCentre);

        this.construireRubriqueInfosCentre();
        this.construireRubriquePlusProches();
        this.construireRubriqueDistances();
        this.construireRubriqueDurees();

        this.contenuCentre.add(this.titreCentre);
        this.contenuCentre.add(Box.createVerticalStrut(15));
        this.contenuCentre.add(this.panneauInfosCentre);
        this.contenuCentre.add(Box.createVerticalStrut(15));
        this.contenuCentre.add(this.panneauPlusProches);
        this.contenuCentre.add(Box.createVerticalStrut(15));
        this.contenuCentre.add(this.panneauDistances);
        this.contenuCentre.add(Box.createVerticalStrut(15));
        this.contenuCentre.add(this.panneauDurees);
        this.contenuCentre.add(Box.createVerticalGlue());

        this.defilementCentre = new JScrollPane(this.contenuCentre);
        this.defilementCentre.getVerticalScrollBar().setUnitIncrement(16);
        this.panneauCentre.add(this.defilementCentre, BorderLayout.CENTER);
    }

    /**
     * Construit la rubrique affichant l'identifiant et le type du centre
     * sélectionné.
     */
    private void construireRubriqueInfosCentre() {
        this.panneauInfosCentre = new JPanel();
        this.panneauInfosCentre.setLayout(new BoxLayout(this.panneauInfosCentre, BoxLayout.Y_AXIS));
        this.panneauInfosCentre.setBorder(this.creerBordureRubrique());

        this.titreInfosCentre = new JLabel("Infos");
        styliserTitre(this.titreInfosCentre);

        this.labelIdCentre = new JLabel("ID du centre :");
        this.labelIdCentre.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.labelTypeCentre = new JLabel("Type du centre :");
        this.labelTypeCentre.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.panneauInfosCentre.add(this.titreInfosCentre);
        this.panneauInfosCentre.add(Box.createVerticalStrut(10));
        this.panneauInfosCentre.add(this.labelIdCentre);
        this.panneauInfosCentre.add(Box.createVerticalStrut(5));
        this.panneauInfosCentre.add(this.labelTypeCentre);

        this.panneauInfosCentre.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.panneauInfosCentre.getPreferredSize().height));
    }
    
    
    
    
    
    /**
     * Construit la table affichant, pour chaque type de centre, le centre le
     * plus proche du centre sélectionné (en durée et en durée estimée).
     */
    private void construireRubriquePlusProches() {
        this.modelePlusProches = new DefaultTableModel(
                new Object[]{"Type", "Id du centre le plus proche", "Durée (min)", "Durée estimée (min)"}, 0);
        this.tablePlusProches = new JTable(this.modelePlusProches);
        this.defilementPlusProches = new JScrollPane(this.tablePlusProches);
        this.defilementPlusProches.setPreferredSize(new Dimension(400, 100));

        this.titrePlusProches = new JLabel("Centres les plus proches par type");
        this.panneauPlusProches = this.assemblerRubriqueTableau(this.titrePlusProches, this.defilementPlusProches);
    }

    /**
     * Remplit la table des centres les plus proches pour les trois types
     * (M, O, N), à partir du centre sélectionné.
     *
     * @param idCentreSelectionne l'identifiant du centre de référence
     */
    private void remplirPlusProches(String idCentreSelectionne) {
        this.modelePlusProches.setRowCount(0);

        double[][] matriceDuree = this.district.calculerMatriceDurees();
        double[][] matriceDureeEstimee = this.district.calculerMatriceDureesEstimees();

        int indexSelectionne = district.trouverIndexParId(idCentreSelectionne);

        this.ajouterLignePlusProche("M", indexSelectionne, matriceDuree, matriceDureeEstimee);
        this.ajouterLignePlusProche("O", indexSelectionne, matriceDuree, matriceDureeEstimee);
        this.ajouterLignePlusProche("N", indexSelectionne, matriceDuree, matriceDureeEstimee);
    }

    /**
     * Recherche le centre le plus proche d'un type donné et ajoute une ligne
     * à la table des centres les plus proches.
     *
     * @param type                 le type de centre recherché ("M", "O" ou "N")
     * @param indexSelectionne     l'indice du centre de référence
     * @param matriceDuree         la matrice des durées standard
     * @param matriceDureeEstimee  la matrice des durées estimées
     */
    private void ajouterLignePlusProche(String type, int indexSelectionne, double[][] matriceDuree, double[][] matriceDureeEstimee) {
        List<CentreSante> centres = this.district.getCentres();
        int meilleurIndex = -1;
        double meilleureDuree = Double.MAX_VALUE;

        for (int i = 0; i < centres.size(); i++) {
            if (centres.get(i).getType().equals(type) && i != indexSelectionne) {
                double duree = matriceDuree[indexSelectionne][i];
                if (duree < meilleureDuree) {
                    meilleureDuree = duree;
                    meilleurIndex = i;
                }
            }
        }

        if (meilleurIndex != -1) {
            String id = centres.get(meilleurIndex).getId();
            double dureeEstimee = matriceDureeEstimee[indexSelectionne][meilleurIndex];
            this.modelePlusProches.addRow(new Object[]{type, id, meilleureDuree, dureeEstimee});
        }
    }

    /**
     * Construit la table affichant les distances directes (en km) entre le
     * centre sélectionné et tous les autres centres.
     */
    private void construireRubriqueDistances() {
        this.modeleDistances = new DefaultTableModel(new Object[]{"Type", "Id", "Distance (km)"}, 0);
        this.tableDistances = new JTable(this.modeleDistances);
        this.defilementDistances = new JScrollPane(this.tableDistances);
        this.defilementDistances.setPreferredSize(new Dimension(400, 150));

        this.titreDistances = new JLabel("Distances avec tous les centres");
        this.panneauDistances = this.assemblerRubriqueTableau(this.titreDistances, this.defilementDistances);
    }

    /**
     * Remplit la table des distances directes pour les trois types de
     * centre (M, O, N), à partir du centre sélectionné.
     *
     * @param idCentreSelectionne l'identifiant du centre de référence
     */
    private void remplirDistances(String idCentreSelectionne) {
        this.modeleDistances.setRowCount(0);
        this.ajouterLignesDistances("M", idCentreSelectionne);
        this.ajouterLignesDistances("O", idCentreSelectionne);
        this.ajouterLignesDistances("N", idCentreSelectionne);
    }

    /**
     * Ajoute une ligne par centre d'un type donné ayant une route directe
     * avec le centre sélectionné.
     *
     * @param type                le type de centre recherché ("M", "O" ou "N")
     * @param idCentreSelectionne l'identifiant du centre de référence
     */
    private void ajouterLignesDistances(String type, String idCentreSelectionne) {
        CentreSante selectionne = district.trouverCentreParId(idCentreSelectionne);

        for (CentreSante centre : this.district.getCentres()) {
            int distance = this.trouverDistanceDirecte(selectionne, centre);
            if (centre.getType().equals(type) && centre != selectionne && distance != -1) {
                this.modeleDistances.addRow(new Object[]{type, centre.getId(), distance});
            }
        }
    }

    /**
     * Recherche la distance d'une route directe entre deux centres, dans un
     * sens ou dans l'autre.
     *
     * @param a le premier centre
     * @param b le second centre
     * @return la distance de la route directe, ou -1 si aucune route ne relie
     *         directement les deux centres
     */
    private int trouverDistanceDirecte(CentreSante a, CentreSante b) {
        for (Route route : this.district.getRoutes()) {
            boolean sensNormal = route.getSource() == a && route.getDestination() == b;
            boolean sensInverse = route.getSource() == b && route.getDestination() == a;
            if (sensNormal || sensInverse) {
                return route.getDistance();
            }
        }
        return -1;
    }

    /**
     * Construit la table affichant les durées minimales (plus court chemin)
     * entre le centre sélectionné et tous les autres centres.
     */
    private void construireRubriqueDurees() {
        this.modeleDurees = new DefaultTableModel(new Object[]{"Type", "Id", "Durée (min)"}, 0);
        this.tableDurees = new JTable(this.modeleDurees);
        this.defilementDurees = new JScrollPane(this.tableDurees);
        this.defilementDurees.setPreferredSize(new Dimension(400, 150));

        this.titreDurees = new JLabel("Durées minimales avec tous les centres");
        this.panneauDurees = this.assemblerRubriqueTableau(this.titreDurees, this.defilementDurees);
    }

    /**
     * Remplit la table des durées minimales pour les trois types de centre
     * (M, O, N), à partir du centre sélectionné.
     *
     * @param idCentreSelectionne l'identifiant du centre de référence
     */
    private void remplirDurees(String idCentreSelectionne) {
        this.modeleDurees.setRowCount(0);

        double[][] matriceDuree = district.calculerMatriceDurees();
        int indexSelectionne = district.trouverIndexParId(idCentreSelectionne);

        this.ajouterLignesDurees("M", indexSelectionne, matriceDuree);
        this.ajouterLignesDurees("O", indexSelectionne, matriceDuree);
        this.ajouterLignesDurees("N", indexSelectionne, matriceDuree);
    }

    /**
     * Ajoute une ligne par centre d'un type donné, avec la durée du plus
     * court chemin depuis le centre sélectionné.
     *
     * @param type             le type de centre recherché ("M", "O" ou "N")
     * @param indexSelectionne l'indice du centre de référence
     * @param matriceDuree     la matrice des durées standard
     */
    private void ajouterLignesDurees(String type, int indexSelectionne, double[][] matriceDuree) {
        List<CentreSante> centres = this.district.getCentres();

        for (int i = 0; i < centres.size(); i++) {
            if (centres.get(i).getType().equals(type) && i != indexSelectionne) {
                this.modeleDurees.addRow(new Object[]{type, centres.get(i).getId(), matriceDuree[indexSelectionne][i]});
            }
        }
    }

    /**
     * Assemble une rubrique générique composée d'un titre et d'un tableau
     * défilant, avec la bordure commune des rubriques.
     *
     * @param titre      le titre de la rubrique
     * @param defilement le composant défilant contenant le tableau
     * @return le panneau assemblé
     */
    private JPanel assemblerRubriqueTableau(JLabel titre, JScrollPane defilement) {
        JPanel panneau = new JPanel();
        panneau.setLayout(new BoxLayout(panneau, BoxLayout.Y_AXIS));
        panneau.setBorder(this.creerBordureRubrique());

        styliserTitre(titre);
        defilement.setAlignmentX(Component.CENTER_ALIGNMENT);

        panneau.add(titre);
        panneau.add(Box.createVerticalStrut(10));
        panneau.add(defilement);

        panneau.setMaximumSize(new Dimension(Integer.MAX_VALUE, panneau.getPreferredSize().height));
        return panneau;
    }

    /**
     * Met en gras et agrandit le label donné pour en faire un titre de
     * rubrique, et le centre horizontalement.
     *
     * @param titre le label à styliser
     */
    private static void styliserTitre(JLabel titre) {
        float tailleTitre = titre.getFont().getSize() + (float) INCREMENT_TAILLE_TITRE;
        titre.setFont(titre.getFont().deriveFont(Font.BOLD, tailleTitre));
        titre.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    /**
     * Construit la bordure noire encadrant chaque rubrique de la fenêtre.
     *
     * @return la bordure à appliquer
     */
    private Border creerBordureRubrique() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.black, 2),
                BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }
}