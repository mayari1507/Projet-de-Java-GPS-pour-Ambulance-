/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IHM;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import projet_sae.Graphe;

/**
 * Fenêtre d'accueil du projet, permettant de choisir le mode de création du
 * district : à partir d'un fichier CSV existant, ou par génération
 * aléatoire d'un nombre de centres donné.
 *
 * Valider l'un des deux choix ouvre la FenetreTraitement correspondante.
 *
 * @author idris
 */
public class FenetrePrincipale extends JFrame {

    /** Panneau regroupant les deux blocs de choix (fichier / aléatoire). */
    private JPanel panneauCentral;

    /** Bloc de gauche : chargement à partir d'un fichier. */
    private JPanel panneauFichier;

    /** Bloc de droite : génération aléatoire. */
    private JPanel panneauAleatoire;

    /** Ligne contenant le label et le champ de saisie du nombre de centres. */
    private JPanel ligneSaisie;

    /** Titre du bloc fichier. */
    private JLabel titreFichier;

    /** Titre du bloc aléatoire. */
    private JLabel titreAleatoire;

    /** Label du champ de saisie du nombre de centres. */
    private JLabel labelNombreCentres;

    /** Liste déroulante des fichiers CSV disponibles dans le dossier data. */
    private JComboBox<String> listeFichiers;

    /** Modèle de la liste déroulante des fichiers. */
    private DefaultComboBoxModel<String> modeleFichiers;

    /** Bouton de validation du chargement par fichier. */
    private JButton boutonValiderFichier;

    /** Champ de saisie du nombre de centres à générer aléatoirement. */
    private JTextField champNombreCentres;

    /** Bouton de validation de la génération aléatoire. */
    private JButton boutonValiderAleatoire;

    /**
     * Construit la fenêtre principale et initialise tous ses composants.
     */
    public FenetrePrincipale() {
        super("Projet SAÉ - Fenêtre principale");
        this.initComposants();
    }

    /**
     * Retourne la liste déroulante des fichiers disponibles.
     *
     * @return la liste déroulante des fichiers
     */
    public JComboBox<String> getListeFichiers() {
        return listeFichiers;
    }

    /**
     * Initialise et assemble tous les composants graphiques de la fenêtre.
     */
    private void initComposants() {

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 280);
        this.setLocationRelativeTo(null);

        this.titreFichier = new JLabel("À partir d'un fichier");
        this.modeleFichiers = new DefaultComboBoxModel<>();
        this.remplirModeleFichiers();
        this.listeFichiers = new JComboBox<>(this.modeleFichiers);
        this.boutonValiderFichier = new JButton("Valider");

        this.titreAleatoire = new JLabel("Génération aléatoire");
        this.labelNombreCentres = new JLabel("Nombre de centres :");
        this.champNombreCentres = new JTextField(8);
        this.boutonValiderAleatoire = new JButton("Valider");

        Font policeParDefaut = this.titreFichier.getFont();
        float taillePolice = policeParDefaut.getSize() + 5f;
        Font policeTitre = policeParDefaut.deriveFont(Font.BOLD, taillePolice);
        this.titreFichier.setFont(policeTitre);
        this.titreAleatoire.setFont(policeTitre);

        Dimension tailleListe = new Dimension(160, this.listeFichiers.getPreferredSize().height);
        this.listeFichiers.setPreferredSize(tailleListe);
        this.listeFichiers.setMaximumSize(tailleListe);

        this.panneauFichier = new JPanel();
        this.panneauFichier.setLayout(new BoxLayout(this.panneauFichier, BoxLayout.Y_AXIS));
        this.panneauFichier.setBorder(this.creerBordureRubrique());

        this.titreFichier.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.listeFichiers.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.boutonValiderFichier.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.panneauFichier.add(Box.createVerticalGlue());
        this.panneauFichier.add(this.titreFichier);
        this.panneauFichier.add(Box.createVerticalStrut(20));
        this.panneauFichier.add(this.listeFichiers);
        this.panneauFichier.add(Box.createVerticalStrut(20));
        this.panneauFichier.add(this.boutonValiderFichier);
        this.panneauFichier.add(Box.createVerticalGlue());

        this.ligneSaisie = new JPanel(new FlowLayout(FlowLayout.CENTER));
        this.ligneSaisie.add(this.labelNombreCentres);
        this.ligneSaisie.add(this.champNombreCentres);
        this.ligneSaisie.setMaximumSize(this.ligneSaisie.getPreferredSize());

        this.panneauAleatoire = new JPanel();
        this.panneauAleatoire.setLayout(new BoxLayout(this.panneauAleatoire, BoxLayout.Y_AXIS));
        this.panneauAleatoire.setBorder(this.creerBordureRubrique());

        this.titreAleatoire.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.ligneSaisie.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.boutonValiderAleatoire.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.panneauAleatoire.add(Box.createVerticalGlue());
        this.panneauAleatoire.add(this.titreAleatoire);
        this.panneauAleatoire.add(Box.createVerticalStrut(20));
        this.panneauAleatoire.add(this.ligneSaisie);
        this.panneauAleatoire.add(Box.createVerticalStrut(20));
        this.panneauAleatoire.add(this.boutonValiderAleatoire);
        this.panneauAleatoire.add(Box.createVerticalGlue());

        this.panneauCentral = new JPanel(new GridLayout(1, 2, 10, 0));
        this.panneauCentral.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panneauCentral.add(this.panneauFichier);
        this.panneauCentral.add(this.panneauAleatoire);

        this.add(this.panneauCentral, BorderLayout.CENTER);

        this.ajouterEcouteurs();

        this.setVisible(true);
    }

    /**
     * Attache les écouteurs des deux boutons de validation.
     *
     * Le bouton fichier charge le CSV sélectionné et ouvre la fenêtre de
     * traitement. Le bouton aléatoire génère un district de la taille saisie
     * et ouvre également la fenêtre de traitement.
     */
    private void ajouterEcouteurs() {
        this.boutonValiderFichier.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fichierSelectionne = (String) listeFichiers.getSelectedItem();
                Graphe district = new Graphe();
                try {
                    district.chargerCSV("./data/" + fichierSelectionne);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(
                            FenetrePrincipale.this,
                            "Erreur lors du chargement du fichier : " + ex.getMessage(),
                            "Erreur de chargement",
                            JOptionPane.ERROR_MESSAGE);
                }
                district.construireGraphe();
                district.afficher();

                new FenetreTraitement(district) ;
            }
        });

        this.boutonValiderAleatoire.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreAleatoire = champNombreCentres.getText().trim();
                if (nombreAleatoire.isEmpty()) {
                    JOptionPane.showMessageDialog(
                            FenetrePrincipale.this,
                            "Veuillez saisir un nombre de centres.",
                            "Champ vide",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    int nb = Integer.parseInt(nombreAleatoire);
                    Graphe district = new Graphe();
                    district.genererAleatoire(nb);
                    district.construireGraphe();
                    district.afficher();
                    new FenetreTraitement(district);
                }
            }
        });
    }

    /**
     * Remplit la liste déroulante avec le nom de chaque fichier présent dans
     * le dossier data.
     */
    private void remplirModeleFichiers() {
        File dossierData = new File("data");
        File[] fichiers = dossierData.listFiles();
        if (fichiers != null) {
            for (File fichier : fichiers) {
                if (fichier.isFile()) {
                    this.modeleFichiers.addElement(fichier.getName());
                }
            }
        }
        
    }

    /**
     * Construit la bordure noire encadrant chaque rubrique de la fenêtre.
     *
     * @return la bordure à appliquer
     */
    private Border creerBordureRubrique() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.black, 2),
                BorderFactory.createEmptyBorder(15, 15, 15, 15));
    }
}