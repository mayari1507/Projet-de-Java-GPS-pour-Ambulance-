/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projet_sae;

/**
 * Représente un centre de santé du district.
 *
 * Cette classe est abstraite : chaque centre est instancié via l'un de ses
 * sous-types (Maternite, BlocOperatoire, Nutrition), qui fixe le code de
 * type associé.
 *
 * @author idris
 */
public abstract class CentreSante {

    /** Identifiant unique du centre (par exemple "S1"). */
    private String id;

    /** Code du type de centre : "M" (maternité), "O" (bloc opératoire) ou "N" (nutrition). */
    private String type;

    /**
     * Construit un centre de santé avec son identifiant et son type.
     *
     * @param id   l'identifiant du centre
     * @param type le code du type de centre
     */
    public CentreSante(String id, String type) {
        this.id = id;
        this.type = type;
    }

    /**
     * Retourne l'identifiant du centre.
     *
     * @return l'identifiant du centre
     */
    public String getId() {
        return id;
    }

    /**
     * Retourne le code du type du centre.
     *
     * @return le code du type ("M", "O" ou "N")
     */
    public String getType() {
        return type;
    }
}