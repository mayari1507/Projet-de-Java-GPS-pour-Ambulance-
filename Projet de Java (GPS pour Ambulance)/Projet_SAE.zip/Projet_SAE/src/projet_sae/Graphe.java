package projet_sae;

import org.graphstream.algorithm.APSP;
import org.graphstream.algorithm.APSP.APSPInfo;
import org.graphstream.algorithm.Dijkstra;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.Path;
import org.graphstream.graph.implementations.SingleGraph;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Math.max;

/**
 * Représente le réseau de centres de santé d'un district sous forme de graphe.
 *
 * Un graphe est composé de centres de santé (les sommets) reliés par des routes
 * (les arêtes). La classe permet de charger un réseau depuis un fichier CSV ou
 * d'en générer un aléatoirement, de l'afficher avec GraphStream, et de calculer
 * des tournées de livraison (un ou deux camions) à l'aide d'une matrice des
 * plus courts chemins.
 *
 * @author mohamed
 */
public class Graphe {

    /** Valeur utilisée pour représenter une durée infinie (aucun chemin connu). */
    private static final double INFINI = 999999;

    /** Graphe GraphStream utilisé pour l'affichage et les algorithmes de la librairie. */
    private Graph graphe;

    /** Liste des centres de santé du district. */
    private List<CentreSante> centres;

    /** Liste des routes reliant les centres. */
    private List<Route> routes;

    /**
     * Initialise un Graphe avec la liste des centres et des routes qui le composent
     */
    public Graphe() {
        graphe = new SingleGraph("Réseau de Santé");
        centres = new ArrayList<CentreSante>();
        routes = new ArrayList<Route>();
    }

    /**
     * Retourne la liste des centres de santé du réseau.
     *
     * @return la liste des centres
     */
    public List<CentreSante> getCentres() {
        return centres;
    }

    /**
     * Retourne la liste des routes du réseau.
     *
     * @return la liste des routes
     */
    public List<Route> getRoutes() {
        return routes;
    }

    /**
     * Retourne le graphe GraphStream sous-jacent.
     *
     * @return le graphe GraphStream
     */
    public Graph getGraph() {
        return graphe;
    }

    /**
     * Remplace le graphe GraphStream sous-jacent.
     *
     * Utile pour réinitialiser l'affichage sans recréer tout l'objet Graphe.
     *
     * @param graphe le nouveau graphe GraphStream à utiliser
     */
    public void setGraphe(Graph graphe) {
        this.graphe = graphe;
    }

    /**
     * Charge un réseau de centres depuis un fichier CSV.
     *
     * Le fichier décrit une matrice d'adjacence : chaque ligne commence par
     * l'identifiant et le type d'un centre, suivis d'une cellule par centre (un
     * 0 s'il n'y a pas de route, sinon un triplet fiabilite,distance,duree).
     * Les lignes vides et les lignes de commentaire (commençant par //) sont
     * ignorées.
     *
     * @param cheminFichier le chemin du fichier CSV à charger
     * @throws IOException si le fichier ne peut pas être lu
     */
    public void chargerCSV(String cheminFichier) throws IOException {
        List<String[]> lignesDonnees = new ArrayList<String[]>();

        try {
            FileInputStream fichier = new FileInputStream(cheminFichier);
            Scanner scanner = new Scanner(fichier);
            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine().trim();
                if (!ligne.isEmpty() && !ligne.startsWith("//") && !ligne.replace(";", "").isEmpty()) {
                    lignesDonnees.add(ligne.split(";"));
                }
            }
            scanner.close();
        } catch (Exception e) {
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }

        for (int i = 0; i < lignesDonnees.size(); i++) {
            String[] colonnes = lignesDonnees.get(i);
            if (colonnes.length >= 2) {
                String id = colonnes[0].trim();
                String type = colonnes[1].trim();
                if (!id.isEmpty()) {
                    CentreSante centre = creerCentre(id, type);
                    if (centre != null) {
                        centres.add(centre);
                    }
                }
            }
        }

        for (int i = 0; i < centres.size(); i++) {
            String[] colonnes = lignesDonnees.get(i);
            for (int j = i + 1; j < centres.size(); j++) {
                int indexColonne = 2 + j;
                if (indexColonne < colonnes.length) {
                    String cellule = colonnes[indexColonne].trim();
                    if (!cellule.equals("0") && !cellule.isEmpty()) {
                        try {
                            String[] triplet = cellule.split(",");
                            if (triplet.length >= 3) {
                                double fiabilite = Integer.parseInt(triplet[0].trim()) / 10.0;
                                int distance = Integer.parseInt(triplet[1].trim());
                                int duree = Integer.parseInt(triplet[2].trim());
                                Route route = new Route(centres.get(i), centres.get(j), fiabilite, distance, duree);
                                routes.add(route);
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Cellule ignorée (format invalide) : " + cellule);
                        }
                    }
                }
            }
        }
    }

    /**
     * Instancie le bon sous-type de CentreSante selon la lettre de type.
     *
     * @param id   l'identifiant du centre
     * @param type le code du type : "M" (maternité), "O" (bloc opératoire) ou "N" (nutrition)
     * @return le centre créé
     * @throws IllegalArgumentException si le code de type est inconnu ou vide
     */
    private CentreSante creerCentre(String id, String type) {
        if (type != null && !type.isEmpty()) {
            char premiereLettre = type.charAt(0);
            if (premiereLettre == 'M') {
                return new Maternite(id);
            }
            if (premiereLettre == 'O') {
                return new BlocOperatoire(id);
            }
            if (premiereLettre == 'N') {
                return new Nutrition(id);
            }
        }
        throw new IllegalArgumentException("Type de centre inconnu : " + type);
    }

    /**
     * Ajoute tous les nœuds et toutes les arêtes dans le graphe GraphStream,
     * puis y associe les attributs métier.
     *
     * Doit être appelée après chargerCSV ou genererAleatoire.
     */
    public void construireGraphe() {

        for (int i = 0; i < centres.size(); i++) {
            CentreSante centre = centres.get(i);

            Node noeud = graphe.addNode(centre.getId());

            noeud.setAttribute("ui.label", centre.getId());
            noeud.setAttribute("ui.class", classeDepuisType(centre.getType()));
            noeud.setAttribute("type", centre.getType());
            noeud.setAttribute("description", centre.toString());
        }

        for (int i = 0; i < routes.size(); i++) {
            Route route = routes.get(i);
            String idArete = route.getSource().getId() + "_" + route.getDestination().getId();

            Edge arete = graphe.addEdge(
                    idArete,
                    route.getSource().getId(),
                    route.getDestination().getId()
            );

            arete.setAttribute("ui.label", route.getFiabilite() + "/" + route.getDistance() + " km/" + route.getDuree() + "min");
            arete.setAttribute("fiabilite", route.getFiabilite());
            arete.setAttribute("distance", route.getDistance());
            arete.setAttribute("duree", route.getDuree());
        }
    }

    /**
     * Retourne le nom de la classe CSS GraphStream associée au type de centre.
     *
     * @param type le code du type ("M", "O" ou "N")
     * @return le nom de la classe CSS correspondante
     */
    private String classeDepuisType(String type) {
        if (type.equals("M")) {
            return "maternite";
        }
        if (type.equals("O")) {
            return "operatoire";
        }
        if (type.equals("N")) {
            return "nutrition";
        }
        return "inconnu";
    }

    /**
     * Applique la feuille de style et active la qualité de rendu du graphe.
     *
     * Doit être appelée avant d'afficher le graphe dans une vue.
     */
    public void afficher() {
        graphe.setAttribute("ui.stylesheet", construireStylesheet());
        graphe.setAttribute("ui.quality");
        graphe.setAttribute("ui.antialias");
    }

    /**
     * Construit la feuille de style GraphStream (couleur des centres par type).
     *
     * @return la feuille de style sous forme de chaîne
     */
    private String construireStylesheet() {
        return "node {"
                + "  size: 15px;"
                + "  fill-color: black;"
                + "  text-size: 10;"
                + "  text-color: black;"
                + "  text-style: bold;"
                + "  text-alignment: center;"
                + "}"
                + "node.maternite {"
                + "  fill-color: #FA7025;"
                + "}"
                + "node.operatoire {"
                + "  fill-color: #14A85E;"
                + "}"
                + "node.nutrition {"
                + "  fill-color: #FADD05;"
                + "}"
                + "edge {"
                + "  fill-color: black;"
                + "  text-size: 11;"
                + "  text-color: black;"
                + "  text-background-mode: rounded-box;"
                + "  text-background-color: #ECF0F1;"
                + "}";
    }

    /**
     * Génère aléatoirement un réseau de n centres connecté.
     *
     * Le type de chaque centre est tiré au sort (maternité avec une probabilité
     * de 3/5, bloc opératoire et nutrition avec une probabilité de 1/5 chacun).
     * Un arbre couvrant est d'abord construit pour garantir que le graphe est
     * connexe, puis des routes supplémentaires sont ajoutées avec une
     * probabilité de 1/5.
     *
     * @param n le nombre de centres à générer
     */
    public void genererAleatoire(int n) {
        genererCentres(n);
        genererArbreCouvrant();
        genererRoutesSupplementaires();
    }

    /**
     * Crée n centres de types tirés aléatoirement.
     *
     * @param n le nombre de centres à créer
     */
    private void genererCentres(int n) {
        for (int i = 1; i <= n; i++) {
            String id = "S" + i;
            int tirage = (int) (Math.random() * 5);

            if (tirage <= 2) {
                centres.add(new Maternite(id));
            } else if (tirage == 3) {
                centres.add(new BlocOperatoire(id));
            } else {
                centres.add(new Nutrition(id));
            }
        }
    }

    /**
     * Relie chaque centre à un centre déjà placé pour garantir la connexité.
     *
     * Chaque nouveau centre est relié à un centre tiré au hasard parmi ceux qui
     * le précèdent : il existe ainsi toujours un chemin entre deux centres
     * quelconques.
     */
    private void genererArbreCouvrant() {
        for (int i = 1; i < centres.size(); i++) {
            int j = (int) (Math.random() * i);
            ajouterRoute(i, j);
        }
    }

    /**
     * Ajoute des routes supplémentaires avec une probabilité de 1/5 par couple.
     */
    private void genererRoutesSupplementaires() {
        for (int i = 0; i < centres.size(); i++) {
            for (int j = i + 1; j < centres.size(); j++) {
                if (Math.random() < 0.2) {
                    ajouterRoute(i, j);
                }
            }
        }
    }

    /**
     * Ajoute une route aléatoire entre deux centres si elle n'existe pas déjà.
     *
     * @param i l'indice du premier centre
     * @param j l'indice du second centre
     */
    private void ajouterRoute(int i, int j) {
        CentreSante centreA = centres.get(i);
        CentreSante centreB = centres.get(j);

        if (!routeExisteDeja(centreA, centreB)) {
            int fiabilite = 2 + (int) (Math.random() * 9);
            int distance = 10 + (int) (Math.random() * 41);
            int duree = 10 + (int) (Math.random() * 111);
            routes.add(new Route(centreA, centreB, fiabilite, distance, duree));
        }
    }

    /**
     * Indique si une route relie déjà les deux centres, dans un sens ou
     * l'autre.
     *
     * @param centreA le premier centre
     * @param centreB le second centre
     * @return true si une route existe déjà entre les deux centres
     */
    private boolean routeExisteDeja(CentreSante centreA, CentreSante centreB) {
        for (int k = 0; k < routes.size(); k++) {
            Route route = routes.get(k);
            boolean sensNormal = (route.getSource() == centreA && route.getDestination() == centreB);
            boolean sensInverse = (route.getSource() == centreB && route.getDestination() == centreA);
            if (sensNormal || sensInverse) {
                return true;
            }
        }
        return false;
    }

    /**
     * Calcule et affiche le plus court chemin (en durée standard) entre deux
     * centres, en utilisant l'algorithme de Dijkstra de GraphStream.
     *
     * Le chemin et ses arêtes sont coloriés en violet sur le graphe.
     *
     * @param idDepart  l'identifiant du centre de départ
     * @param idArrivee l'identifiant du centre d'arrivée
     * @return la liste des identifiants des centres traversés, dans l'ordre
     */
    public List<String> plusCourtChemin(String idDepart, String idArrivee) {
        Dijkstra dijkstra = new Dijkstra(Dijkstra.Element.EDGE, null, "duree");
        dijkstra.init(graphe);
        dijkstra.setSource(graphe.getNode(idDepart));
        dijkstra.compute();

        System.out.println("Chemin le plus court (durée) : " + dijkstra.getPath(graphe.getNode(idArrivee)));
        System.out.println("Durée totale : " + dijkstra.getPathLength(graphe.getNode(idArrivee)));

        List<String> chemin = new ArrayList<String>();
        for (Node n : dijkstra.getPathNodes(graphe.getNode(idArrivee))) {
            chemin.add(n.getId());
        }

        colorierChemin(chemin, dijkstra.getPathEdges(graphe.getNode(idArrivee)), "#B300DE");
        dijkstra.clear();
        return chemin;
    }

    /**
     * Colore les arêtes et les sommets d'un chemin sur le graphe.
     *
     * Les arêtes reçoivent la couleur donnée, et chaque sommet reprend la
     * couleur de son type de centre (pour rester lisible après coloriage).
     *
     * @param chemin la liste des identifiants des centres du chemin
     * @param aretes les arêtes du chemin à colorer
     * @param couleur la couleur à appliquer aux arêtes
     */
    private void colorierChemin(List<String> chemin, Iterable<Edge> aretes, String couleur) {
        for (Edge e : aretes) {
            e.setAttribute("ui.style", "fill-color: " + couleur + "; size: 4px;");
            e.setAttribute("ui.label", "");
        }
        for (String id : chemin) {
            Node n = graphe.getNode(id);
            String type = (String) n.getAttribute("type");
            if (type.equals("M")) {
                n.setAttribute("ui.style", "fill-color: #FA7025;");
            } else if (type.equals("O")) {
                n.setAttribute("ui.style", "fill-color: #14A85E;");
            } else if (type.equals("N")) {
                n.setAttribute("ui.style", "fill-color: #FADD05;");
            }
        }
    }

    /**
     * Calcule et affiche le chemin le plus sûr (en durée estimée, tenant compte
     * de la fiabilité) entre deux centres.
     *
     * Les routes interdites sont temporairement retirées du graphe pendant le
     * calcul, puis remises à la fin. Le chemin est colorié en bleu.
     *
     * @param idDepart  l'identifiant du centre de départ
     * @param idArrivee l'identifiant du centre d'arrivée
     * @return la liste des identifiants des centres traversés, dans l'ordre
     */
    public List<String> cheminSecurise(String idDepart, String idArrivee) {
        for (Route r : routes) {
            Edge e = trouverArete(r);
            if (e != null) {
                e.setAttribute("dureeEstimee", r.getDureeEstimee());
            }
        }

        for (Route r : routes) {
            if (r.estInterdite()) {
                Edge e = trouverArete(r);
                if (e != null) {
                    graphe.removeEdge(e);
                }
            }
        }

        Dijkstra dijkstra = new Dijkstra(Dijkstra.Element.EDGE, null, "dureeEstimee");
        dijkstra.init(graphe);
        dijkstra.setSource(graphe.getNode(idDepart));
        dijkstra.compute();

        System.out.println("Chemin sécurisé : " + dijkstra.getPath(graphe.getNode(idArrivee)));
        System.out.println("Coût total : " + dijkstra.getPathLength(graphe.getNode(idArrivee)));

        List<String> chemin = new ArrayList<String>();
        for (Node n : dijkstra.getPathNodes(graphe.getNode(idArrivee))) {
            chemin.add(n.getId());
        }

        colorierChemin(chemin, dijkstra.getPathEdges(graphe.getNode(idArrivee)), "#0055DE");
        dijkstra.clear();

        for (Route r : routes) {
            if (r.estInterdite()) {
                String idArete = r.getSource().getId() + "_" + r.getDestination().getId();
                if (graphe.getEdge(idArete) == null) {
                    Edge e = graphe.addEdge(idArete, r.getSource().getId(), r.getDestination().getId());
                    e.setAttribute("dureeEstimee", r.getDureeEstimee());
                    e.setAttribute("duree", r.getDuree());
                    e.setAttribute("fiabilite", r.getFiabilite());
                    e.setAttribute("distance", r.getDistance());
                    e.setAttribute("ui.label", r.getFiabilite() + "/" + r.getDistance() + " km/" + r.getDuree() + "min");
                }
            }
        }

        return chemin;
    }

    /**
     * Retrouve l'arête GraphStream correspondant à une route, dans un sens ou
     * dans l'autre.
     *
     * @param r la route dont on cherche l'arête
     * @return l'arête correspondante, ou null si elle n'existe pas
     */
    private Edge trouverArete(Route r) {
        String idArete = r.getSource().getId() + "_" + r.getDestination().getId();
        Edge e = graphe.getEdge(idArete);
        if (e == null) {
            e = graphe.getEdge(r.getDestination().getId() + "_" + r.getSource().getId());
        }
        return e;
    }

    /**
     * Estompe les routes dont la fiabilité dépasse le seuil donné, pour ne
     * laisser visibles que les routes les plus risquées.
     *
     * @param seuil le seuil de fiabilité, entre 0 et 100
     */
    public void afficherRoutesRisquees(int seuil) {
        double seuilConverti = seuil / 100.0;

        for (Route r : routes) {
            Edge e = trouverArete(r);
            if (e != null && r.getFiabilite() > seuilConverti) {
                e.setAttribute("ui.style", "fill-color: #D3D3D3; size: 2px;");
                e.setAttribute("ui.label", "");
                e.removeAttribute("fiabilite");
                e.removeAttribute("distance");
                e.removeAttribute("duree");
            }
        }
    }

    /**
     * Épure le graphe pour le rendre lisible avant d'afficher une tournée.
     *
     * Toutes les arêtes sont mises en gris clair et fines, et toutes leurs
     * étiquettes sont retirées. Tous les sommets sont mis en gris et réduits,
     * en ne conservant que leur identifiant comme étiquette.
     */
    public void suppInfos() {
        for (int i = 0; i < graphe.getEdgeCount(); i++) {
            Edge arete = graphe.getEdge(i);
            arete.setAttribute("ui.style", "fill-color: #EBEBEB; size: 1px;");
            arete.removeAttribute("ui.label");
        }
        for (int i = 0; i < graphe.getNodeCount(); i++) {
            Node sommet = graphe.getNode(i);
            sommet.setAttribute("ui.style", "fill-color: #EBEBEB; size: 15px;");
            sommet.setAttribute("ui.label", sommet.getId());
        }
    }

    /**
     * Calcule la matrice des durées des plus courts chemins entre tous les
     * centres, à l'aide de l'algorithme APSP (Floyd-Warshall) de GraphStream.
     *
     * Les résultats sont recopiés dans un tableau pour que les lectures
     * ultérieures (glouton, optimisation, tournées) soient immédiates, ce qui
     * est important sur les grands graphes.
     *
     * @return un tableau où la case [i][j] donne la durée du plus court chemin
     *         du centre i au centre j
     */
    public double[][] calculerMatriceDurees() {
        preparerPoidsDuree();

        APSP apsp = new APSP();
        apsp.init(graphe);
        apsp.setDirected(false);
        apsp.setWeightAttributeName("Duree");
        apsp.compute();

        int n = centres.size();
        double[][] matrice = new double[n][n];

        for (int i = 0; i < n; i++) {
            APSPInfo info = graphe.getNode(centres.get(i).getId()).getAttribute(APSPInfo.ATTRIBUTE_NAME);
            for (int j = 0; j < n; j++) {
                matrice[i][j] = info.getLengthTo(centres.get(j).getId());
            }
        }

        return matrice;
    }

    /**
     * Inscrit la durée de chaque route comme poids sur l'arête correspondante.
     */
    private void preparerPoidsDuree() {
        for (int i = 0; i < routes.size(); i++) {
            Route route = routes.get(i);
            String idArete = route.getSource().getId() + "_" + route.getDestination().getId();
            Edge arete = graphe.getEdge(idArete);
            arete.setAttribute("Duree", (double) route.getDuree());
        }
    }

    /**
     * Calcule la matrice des durées estimées des plus courts chemins entre tous
     * les centres, en tenant compte de la fiabilité des routes.
     *
     * Les routes interdites reçoivent un poids infini et ne sont donc jamais
     * empruntées par le plus court chemin.
     *
     * @return un tableau où la case [i][j] donne la durée estimée du plus court
     *         chemin du centre i au centre j
     */
    public double[][] calculerMatriceDureesEstimees() {
        preparerPoidsDureeEstimee();

        APSP apsp = new APSP();
        apsp.init(graphe);
        apsp.setDirected(false);
        apsp.setWeightAttributeName("poidsDureeEstimee");
        apsp.compute();

        int n = centres.size();
        double[][] matrice = new double[n][n];

        for (int i = 0; i < n; i++) {
            APSPInfo info = graphe.getNode(centres.get(i).getId()).getAttribute(APSPInfo.ATTRIBUTE_NAME);
            for (int j = 0; j < n; j++) {
                matrice[i][j] = info.getLengthTo(centres.get(j).getId());
            }
        }

        return matrice;
    }

    /**
     * Inscrit la durée estimée de chaque route comme poids sur l'arête
     * correspondante. Les routes interdites reçoivent un poids infini.
     */
    private void preparerPoidsDureeEstimee() {
        for (int i = 0; i < routes.size(); i++) {
            Route route = routes.get(i);
            String idArete = route.getSource().getId() + "_" + route.getDestination().getId();
            Edge arete = graphe.getEdge(idArete);

            if (route.estInterdite()) {
                arete.setAttribute("poidsDureeEstimee", INFINI);
            } else {
                arete.setAttribute("poidsDureeEstimee", route.getDureeEstimee());
            }
        }
    }

    /**
     * Retrouve l'indice d'un centre à partir de son identifiant.
     *
     * @param idCentre l'identifiant du centre recherché
     * @return l'indice du centre dans la liste des centres, ou -1 s'il n'existe pas
     */
    public int trouverIndexParId(String idCentre) {
        for (int i = 0; i < centres.size(); i++) {
            if (centres.get(i).getId().equals(idCentre)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Retrouve un centre à partir de son identifiant.
     *
     * @param idCentre l'identifiant du centre recherché
     * @return le centre correspondant, ou null s'il n'existe pas
     */
    public CentreSante trouverCentreParId(String idCentre) {
        for (int i = 0; i < centres.size(); i++) {
            if (centres.get(i).getId().equals(idCentre)) {
                return centres.get(i);
            }
        }
        return null;
    }

    /**
     * Retourne les indices des centres à livrer selon le type demandé.
     *
     * @param type "tous" pour tous les centres, ou un code de type ("M", "O", "N")
     * @return la liste des indices des centres concernés
     */
    public List<Integer> centresALivrer(String type) {
        List<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < centres.size(); i++) {
            if (type.equals("tous") || centres.get(i).getType().equals(type)) {
                indices.add(i);
            }
        }
        return indices;
    }

    /**
     * Calcule une tournée par l'algorithme glouton, depuis le centre 1.
     *
     * À chaque étape, le camion se rend au centre non encore livré le plus
     * proche en durée. Les durées sont lues dans la matrice des plus courts
     * chemins, ce qui prend implicitement en compte le passage par des centres
     * intermédiaires.
     *
     * @param matrice la matrice des durées des plus courts chemins
     * @param aLivrer les indices des centres à livrer
     * @return l'ordre de visite des centres (commençant par le centre 0)
     */
    public List<Integer> glouton(double[][] matrice, List<Integer> aLivrer) {
        List<Integer> tournee = new ArrayList<Integer>();
        List<Integer> restants = new ArrayList<Integer>();

        for (int i = 0; i < aLivrer.size(); i++) {
            restants.add(aLivrer.get(i));
        }

        tournee.add(0);
        retirerCentreDepart(restants);

        int positionActuelle = 0;
        while (!restants.isEmpty()) {
            int meilleurIndex = indexCentreLePlusProche(matrice, positionActuelle, restants);
            int meilleurCentre = restants.get(meilleurIndex);
            tournee.add(meilleurCentre);
            restants.remove(meilleurIndex);
            positionActuelle = meilleurCentre;
        }

        return tournee;
    }

    /**
     * Retire le centre de départ (indice 0) de la liste des centres restants.
     *
     * @param restants la liste des centres à livrer
     */
    private void retirerCentreDepart(List<Integer> restants) {
        for (int i = 0; i < restants.size(); i++) {
            if (restants.get(i) == 0) {
                restants.remove(i);
            }
        }
    }

    /**
     * Cherche, parmi les centres restants, l'indice (dans la liste restants) du
     * centre le plus proche de la position actuelle.
     *
     * @param matrice          la matrice des durées
     * @param positionActuelle l'indice du centre où se trouve le camion
     * @param restants         les centres non encore livrés
     * @return l'indice du centre le plus proche dans la liste restants
     */
    private int indexCentreLePlusProche(double[][] matrice, int positionActuelle, List<Integer> restants) {
        int meilleurIndex = -1;
        double meilleureDuree = INFINI;

        for (int i = 0; i < restants.size(); i++) {
            int candidat = restants.get(i);
            double duree = matrice[positionActuelle][candidat];
            if (duree < meilleureDuree) {
                meilleureDuree = duree;
                meilleurIndex = i;
            }
        }

        return meilleurIndex;
    }

    /**
     * Améliore une tournée existante avec l'algorithme 2-opt.
     *
     * Le 2-opt inverse des segments de la tournée tant que cela la raccourcit.
     * Le calcul du gain est incrémental (seules les arêtes de bord changent),
     * ce qui le rend rapide même sur de grands graphes. L'optimisation s'arrête
     * d'elle-même lorsqu'aucune inversion ne diminue plus la durée.
     *
     * @param matrice la matrice des durées des plus courts chemins
     * @param aLivrer les indices des centres à livrer (non utilisé directement,
     *                la tournée de départ fournit déjà l'ensemble à optimiser)
     * @param tournee la tournée de départ à optimiser (modifiée sur place)
     * @return la tournée optimisée
     */
    public List<Integer> gloutonOptimise(double[][] matrice, List<Integer> aLivrer, List<Integer> tournee) {
        boolean amelioration = true;

        while (amelioration) {
            amelioration = false;
            for (int i = 1; i < tournee.size() - 1; i++) {
                for (int j = i + 1; j < tournee.size(); j++) {
                    if (inversionAmeliore(matrice, tournee, i, j)) {
                        inverserSegment(tournee, i, j);
                        amelioration = true;
                    }
                }
            }
        }

        return tournee;
    }

    /**
     * Indique si inverser le segment entre les positions i et j raccourcit la
     * tournée.
     *
     * Seules les deux arêtes situées aux bords du segment changent : on compare
     * donc directement leur durée avant et après inversion, sans recalculer
     * toute la tournée.
     *
     * @param matrice la matrice des durées
     * @param tournee la tournée courante
     * @param i       la position de début du segment
     * @param j       la position de fin du segment
     * @return true si l'inversion diminue la durée totale
     */
    private boolean inversionAmeliore(double[][] matrice, List<Integer> tournee, int i, int j) {
        int a = tournee.get(i - 1);
        int b = tournee.get(i);
        int c = tournee.get(j);

        double avant = matrice[a][b];
        double apres = matrice[a][c];

        if (j < tournee.size() - 1) {
            int d = tournee.get(j + 1);
            avant = avant + matrice[c][d];
            apres = apres + matrice[b][d];
        }

        return apres < avant;
    }

    /**
     * Inverse l'ordre des centres entre les positions i et j de la tournée.
     *
     * @param tournee la tournée à modifier
     * @param i       la position de début du segment
     * @param j       la position de fin du segment
     */
    private void inverserSegment(List<Integer> tournee, int i, int j) {
        List<Integer> temp = new ArrayList<Integer>();
        for (int x = j; x >= i; x--) {
            temp.add(tournee.get(x));
        }
        for (int x = i; x <= j; x++) {
            tournee.set(x, temp.get(x - i));
        }
    }

    /**
     * Répartit les centres entre deux camions de façon à équilibrer leurs durées.
     *
     * Une grande tournée optimisée est découpée à chaque position possible. On
     * retient la coupure qui minimise la durée du camion le plus lent, ce qui
     * est l'objectif du sujet.
     *
     * @param matrice       la matrice des durées des plus courts chemins
     * @param aLivrer       les indices des centres à livrer (non utilisé
     *                      directement, la grande tournée fournit déjà
     *                      l'ensemble à répartir)
     * @param grandeTournee la tournée complète (un seul camion) à découper en deux
     * @return une liste de deux tournées (camion 1 et camion 2)
     */
    public List<List<Integer>> deuxCamions(double[][] matrice, List<Integer> aLivrer, List<Integer> grandeTournee) {
        List<Integer> meilleurCamion1 = new ArrayList<Integer>();
        List<Integer> meilleurCamion2 = new ArrayList<Integer>();
        double meilleurMax = INFINI;

        for (int coupure = 1; coupure < grandeTournee.size(); coupure++) {
            List<Integer> camion1 = sousTournee(grandeTournee, 1, coupure);
            List<Integer> camion2 = sousTournee(grandeTournee, coupure, grandeTournee.size());

            double maxDuree = max(calculerDureeTournee(matrice, camion1), calculerDureeTournee(matrice, camion2));

            if (maxDuree < meilleurMax) {
                meilleurMax = maxDuree;
                meilleurCamion1 = camion1;
                meilleurCamion2 = camion2;
            }
        }

        List<List<Integer>> solution = new ArrayList<List<Integer>>();
        solution.add(meilleurCamion1);
        solution.add(meilleurCamion2);
        return solution;
    }

    /**
     * Construit une sous-tournée partant du centre 0 et contenant les centres
     * de la grande tournée situés entre deux positions.
     *
     * @param grandeTournee la tournée complète à découper
     * @param debut         la position de début (incluse)
     * @param fin           la position de fin (exclue)
     * @return la sous-tournée, commençant par le centre 0
     */
    private List<Integer> sousTournee(List<Integer> grandeTournee, int debut, int fin) {
        List<Integer> sousTournee = new ArrayList<Integer>();
        sousTournee.add(0);
        for (int i = debut; i < fin; i++) {
            sousTournee.add(grandeTournee.get(i));
        }
        return sousTournee;
    }

    /**
     * Calcule la durée totale d'une tournée.
     *
     * @param matrice la matrice des durées des plus courts chemins
     * @param tournee l'ordre de visite des centres
     * @return la somme des durées entre centres consécutifs
     */
    public double calculerDureeTournee(double[][] matrice, List<Integer> tournee) {
        double total = 0.0;
        for (int i = 0; i < tournee.size() - 1; i++) {
            int depart = tournee.get(i);
            int arrivee = tournee.get(i + 1);
            total = total + matrice[depart][arrivee];
        }
        return total;
    }

    /**
     * Affiche une tournée et sa durée totale dans la console.
     *
     * @param matrice la matrice des durées
     * @param tournee la tournée à afficher
     */
    public void afficherTournee(double[][] matrice, List<Integer> tournee) {
        System.out.print("Tournée : " + tourneeEnTexte(tournee));
        System.out.println("  (" + calculerDureeTournee(matrice, tournee) + " min)");
    }

    /**
     * Construit la représentation textuelle d'une tournée (S1 ; S5 ; ...).
     *
     * @param tournee la tournée à représenter
     * @return la chaîne décrivant l'ordre de visite
     */
    private String tourneeEnTexte(List<Integer> tournee) {
        String texte = "";
        for (int i = 0; i < tournee.size(); i++) {
            texte = texte + centres.get(tournee.get(i)).getId();
            if (i < tournee.size() - 1) {
                texte = texte + " ; ";
            }
        }
        return texte;
    }

    /**
     * Met en évidence une tournée sur le graphe en colorant ses arêtes et ses
     * sommets.
     *
     * Les arêtes du plus court chemin entre centres consécutifs et les sommets
     * de la tournée prennent la couleur donnée. Le centre de départ est mis en
     * noir et légèrement agrandi pour le distinguer.
     *
     * @param tournee la tournée à mettre en évidence
     * @param couleur la couleur à appliquer (format GraphStream, ex. "#EFA1F0")
     */
    public void changerCouleur(List<Integer> tournee, String couleur) {
        int taille = 15;

        for (int i = 0; i < tournee.size() - 1; i++) {
            CentreSante depart = centres.get(tournee.get(i));
            CentreSante arrivee = centres.get(tournee.get(i + 1));

            APSPInfo info = graphe.getNode(depart.getId()).getAttribute(APSPInfo.ATTRIBUTE_NAME);
            Path chemin = info.getShortestPathTo(arrivee.getId());

            for (int k = 0; k < chemin.getEdgeCount(); k++) {
                chemin.getEdgePath().get(k).setAttribute("ui.style", "fill-color: " + couleur + "; size: 4px;");
            }
        }

        for (int i = 0; i < tournee.size(); i++) {
            Node sommet = graphe.getNode(centres.get(tournee.get(i)).getId());
            sommet.setAttribute("ui.style", "fill-color: " + couleur + "; size: " + taille + "px;");
        }

        String idDepart = centres.get(0).getId();
        int tailleIdDepart = taille + (10 * taille) / 100;
        graphe.getNode(idDepart).setAttribute("ui.style", "fill-color: black; size: " + tailleIdDepart + "px;");
    }

    /**
     * Calcule et affiche la tournée gloutonne d'un camion pour un type de
     * centres donné.
     *
     * @param type    "tous" ou un code de type ("M", "O", "N")
     * @param matrice la matrice des durées des plus courts chemins
     * @return la tournée gloutonne calculée
     */
    public List<Integer> Algo1CamionGlouton(String type, double[][] matrice) {
        List<Integer> aLivrer = centresALivrer(type);
        List<Integer> tournee = glouton(matrice, aLivrer);
        suppInfos();
        changerCouleur(tournee, "#EFA1F0");
        return tournee;
    }

    /**
     * Optimise une tournée gloutonne avec le 2-opt puis l'affiche.
     *
     * @param type           "tous" ou un code de type ("M", "O", "N")
     * @param matrice        la matrice des durées des plus courts chemins
     * @param tourneeGlouton la tournée gloutonne à optimiser
     * @return la tournée optimisée
     */
    public List<Integer> Algo1CamionOptimise(String type, double[][] matrice, List<Integer> tourneeGlouton) {
        List<Integer> aLivrer = centresALivrer(type);
        List<Integer> tournee = gloutonOptimise(matrice, aLivrer, tourneeGlouton);
        suppInfos();
        changerCouleur(tournee, "#EFA1F0");
        return tournee;
    }

    /**
     * Répartit une grande tournée entre deux camions, puis affiche les deux
     * trajets en couleurs distinctes.
     *
     * @param type                   "tous" ou un code de type ("M", "O", "N")
     * @param matrice                la matrice des durées des plus courts chemins
     * @param tourneeGloutonOptimise la grande tournée à découper en deux
     * @return les deux tournées (camion 1 et camion 2)
     */
    public List<List<Integer>> Algo2Camion(String type, double[][] matrice, List<Integer> tourneeGloutonOptimise) {
        List<Integer> aLivrer = centresALivrer(type);
        List<List<Integer>> solution = deuxCamions(matrice, aLivrer, tourneeGloutonOptimise);
        suppInfos();
        changerCouleur(solution.get(0), "#EFA1F0");
        changerCouleur(solution.get(1), "#8A5F4A");
        return solution;
    }

    /**
     * Crée un graphe aléatoire de n centres, déjà construit et prêt à l'emploi.
     *
     * @param n le nombre de centres à générer
     * @return le graphe généré
     */
    public static Graphe GrapheAlea(int n) {
        Graphe g = new Graphe();
        g.genererAleatoire(n);
        g.construireGraphe();
        return g;
    }

    /**
     * Crée un graphe à partir d'un fichier CSV, déjà construit et prêt à
     * l'emploi.
     *
     * @param cheminFichier le chemin du fichier CSV à charger
     * @return le graphe chargé
     * @throws IOException si le fichier ne peut pas être lu
     */
    public static Graphe GrapheFichier(String cheminFichier) throws IOException {
        Graphe g = new Graphe();
        g.chargerCSV(cheminFichier);
        g.construireGraphe();
        return g;
    }
}