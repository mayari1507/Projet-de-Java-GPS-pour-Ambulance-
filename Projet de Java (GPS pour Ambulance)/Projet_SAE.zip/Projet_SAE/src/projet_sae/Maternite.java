/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projet_sae;

/**
 * Représente un centre de santé de type maternité.
 *
 * @author idris
 */
public class Maternite extends CentreSante {

    /**
     * Construit une maternité avec l'identifiant donné.
     *
     * @param id l'identifiant du centre
     */
    public Maternite(String id) {
        super(id, "M");
    }

    /**
     * Retourne une description lisible du centre.
     *
     * @return la description du centre, avec son identifiant
     */
    public String toString() {
        return "Maternité [" + getId() + "]";
    }
}