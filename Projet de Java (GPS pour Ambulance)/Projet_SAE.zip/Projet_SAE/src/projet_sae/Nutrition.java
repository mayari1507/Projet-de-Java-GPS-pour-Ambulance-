/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projet_sae;

/**
 * Représente un centre de santé de type centre de nutrition.
 *
 * @author idris
 */
public class Nutrition extends CentreSante {

    /**
     * Construit un centre de nutrition avec l'identifiant donné.
     *
     * @param id l'identifiant du centre
     */
    public Nutrition(String id) {
        super(id, "N");
    }

    /**
     * Retourne une description lisible du centre.
     *
     * @return la description du centre, avec son identifiant
     */
    public String toString() {
        return "Centre de Nutrition [" + getId() + "]";
    }
}