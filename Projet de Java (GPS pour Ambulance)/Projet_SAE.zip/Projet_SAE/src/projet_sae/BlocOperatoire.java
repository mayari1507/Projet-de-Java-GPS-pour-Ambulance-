/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projet_sae;

/**
 * Représente un centre de santé de type bloc opératoire.
 *
 * @author idris
 */
public class BlocOperatoire extends CentreSante {

    /**
     * Construit un bloc opératoire avec l'identifiant donné.
     *
     * @param id l'identifiant du centre
     */
    public BlocOperatoire(String id) {
        super(id, "O");
    }

    /**
     * Retourne une description lisible du centre.
     *
     * @return la description du centre, avec son identifiant
     */
    public String toString() {
        return "Bloc Opératoire [" + getId() + "]";
    }
}