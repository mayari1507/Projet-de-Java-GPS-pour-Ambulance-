/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projet_sae;


import IHM.FenetrePrincipale ;
import java.io.IOException ;


/**
 *
 * @author idris
 */
public class Projet_SAE {

    public static void main(String[] args) throws IOException {
        FenetrePrincipale f1 = new FenetrePrincipale();

    }
    
}
