/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projet_sae;

/**
 * Représente une route reliant deux centres de santé.
 *
 * Une route porte trois caractéristiques : sa fiabilité (entre 0 et 1, lue
 * depuis un entier 0-10 divisé par 10 lors du chargement), sa distance en
 * kilomètres, et sa durée en minutes. À partir de la fiabilité, la route
 * peut être considérée comme interdite, et une durée estimée tenant compte
 * du risque peut être calculée.
 *
 * @author idris
 */
public class Route {

    /** Centre de départ de la route. */
    private CentreSante source;

    /** Centre d'arrivée de la route. */
    private CentreSante destination;

    /** Fiabilité de la route, comprise entre 0 et 1. */
    private double fiabilite;

    /** Distance de la route, en kilomètres. */
    private int distance;

    /** Durée standard de la route, en minutes. */
    private int duree;

    /**
     * Construit une route entre deux centres avec ses caractéristiques.
     *
     * @param source      le centre de départ
     * @param destination le centre d'arrivée
     * @param fiabilite   la fiabilité de la route (entre 0 et 1)
     * @param distance    la distance de la route, en kilomètres
     * @param duree       la durée standard de la route, en minutes
     */
    public Route(CentreSante source, CentreSante destination, double fiabilite, int distance, int duree) {
        this.source = source;
        this.destination = destination;
        this.fiabilite = fiabilite;
        this.distance = distance;
        this.duree = duree;
    }

    /**
     * Retourne le centre de départ de la route.
     *
     * @return le centre de départ
     */
    public CentreSante getSource() {
        return source;
    }

    /**
     * Retourne le centre d'arrivée de la route.
     *
     * @return le centre d'arrivée
     */
    public CentreSante getDestination() {
        return destination;
    }

    /**
     * Retourne la fiabilité de la route.
     *
     * @return la fiabilité, comprise entre 0 et 1
     */
    public double getFiabilite() {
        return fiabilite;
    }

    /**
     * Retourne la distance de la route.
     *
     * @return la distance, en kilomètres
     */
    public int getDistance() {
        return distance;
    }

    /**
     * Retourne la durée standard de la route.
     *
     * @return la durée, en minutes
     */
    public int getDuree() {
        return duree;
    }

    /**
     * Indique si la route est interdite en raison d'une fiabilité trop
     * faible.
     *
     * Le seuil de 0.25 correspond à une fiabilité de 2.5 sur 10, le seuil
     * fixé par le sujet en dessous duquel une route ne doit jamais être
     * empruntée pour le calcul du chemin sécurisé.
     *
     * @return true si la fiabilité est strictement inférieure à 0.25
     */
    public boolean estInterdite() {
        boolean res = true;
        if (fiabilite >= 0.25) {
            res = false;
        }
        return res;
    }

    /**
     * Calcule la durée estimée de la route, qui pénalise les routes les
     * moins fiables.
     *
     * La formule est : durée x (20 - fiabilité) / 10, où la fiabilité est
     * ici exprimée sur 10 (donc relue comme fiabilité x 10 dans la formule).
     *
     * @return la durée estimée, en minutes
     */
    public double getDureeEstimee() {
        double res = duree * (20 - fiabilite) / 10.0;
        return res;
    }

    /**
     * Retourne une description lisible de la route.
     *
     * @return la description de la route, avec ses trois caractéristiques
     */
    public String toString() {
        return source.getId() + " -> " + destination.getId()
                + "\n fiabilité = " + fiabilite
                + "\n distance = " + distance + " km"
                + "\n durée = " + duree + " min";
    }
}